"""
MT5 Auto-Sync Service - Critical Data Integrity System
Addresses $521.88 discrepancy in account 886528 and ensures real-time MT5 data sync

This service provides:
1. Automated sync every 2 minutes for all accounts
2. Manual force refresh endpoints
3. Redundant data fetching with fallback methods
4. Comprehensive logging and alerting
5. Data validation before database updates
6. Monitoring dashboard for sync health
"""

import asyncio
import logging
import time
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Any, Tuple
from decimal import Decimal
import aiohttp
import os
from dataclasses import dataclass

# Database connection will be imported in initialize method

logger = logging.getLogger(__name__)

@dataclass
class MT5SyncResult:
    """Result of MT5 account sync operation"""
    mt5_login: str
    success: bool
    old_balance: float
    new_balance: float
    balance_change: float
    sync_timestamp: datetime
    error_message: Optional[str] = None
    data_source: str = "mt5_bridge"

class MT5AutoSyncService:
    """Production-grade MT5 auto-sync service with redundancy and monitoring"""
    
    def __init__(self):
        self.bridge_url = os.environ.get('MT5_BRIDGE_URL', 'http://92.118.45.135:8000')
        self.api_key = os.environ.get('MT5_BRIDGE_API_KEY', 'fidus-mt5-bridge-key-2025-secure')
        self.timeout = int(os.environ.get('MT5_BRIDGE_TIMEOUT', '30'))
        self.session = None
        self.sync_running = False
        self.sync_interval = 120  # 2 minutes
        self.retry_attempts = 3
        self.retry_delay = 2
        self.last_sync_results = {}
        self.sync_stats = {
            'total_syncs': 0,
            'successful_syncs': 0,
            'failed_syncs': 0,
            'last_sync_time': None,
            'accounts_synced': set()
        }
        
        # Alert throttling - prevent duplicate emails
        self.last_alert_times = {}  # Store last alert time by alert type
        self.alert_cooldown = 1800  # 30 minutes cooldown between same alerts (reduced email spam)
        
    async def initialize(self):
        """Initialize the sync service"""
        try:
            # Setup HTTP session
            connector = aiohttp.TCPConnector(
                ssl=False,
                limit_per_host=10,
                ttl_dns_cache=300
            )
            
            self.session = aiohttp.ClientSession(
                connector=connector,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                headers={
                    'Content-Type': 'application/json',
                    'X-API-Key': self.api_key
                }
            )
            
            # Get database connection
            from config.database import get_database
            self.db = await get_database()
            
            logger.info("✅ MT5 Auto-Sync Service initialized")
            return True
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize MT5 Auto-Sync Service: {e}")
            return False
    
    async def fetch_mt5_data_with_retry(self, mt5_login: str) -> Dict[str, Any]:
        """Fetch MT5 account data with retry logic and multiple methods"""
        last_error = None
        
        for attempt in range(self.retry_attempts):
            try:
                # Method 1: MT5 Bridge API (primary)
                logger.info(f"🔗 Attempt {attempt + 1}: Trying MT5 Bridge for {mt5_login}")
                result = await self._fetch_via_bridge(mt5_login)
                if result.get('success') and 'balance' in result:
                    logger.debug(f"✅ Bridge success for {mt5_login}: Balance = ${result['balance']}")  # DEBUG level for noise reduction
                    return result
                else:
                    logger.warning(f"⚠️ Bridge failed for {mt5_login}: {result.get('error', 'Unknown error')}")
                    
                # Method 2: Direct broker API (fallback)
                logger.info(f"🔗 Attempt {attempt + 1}: Trying Direct API for {mt5_login}")
                result = await self._fetch_via_direct_api(mt5_login)
                if result.get('success') and 'balance' in result:
                    logger.info(f"✅ Direct API success for {mt5_login}: Balance = ${result['balance']}")
                    return result
                else:
                    logger.warning(f"⚠️ Direct API failed for {mt5_login}: {result.get('error', 'Unknown error')}")
                    
                # Both methods failed for this attempt
                last_error = f"Bridge: {result.get('error', 'Unknown')} | Direct API: Direct broker API not implemented yet"
                    
            except Exception as e:
                import traceback
                last_error = str(e)
                logger.error(f"MT5 fetch attempt {attempt + 1}/{self.retry_attempts} failed for {mt5_login}")
                logger.error(f"Error type: {type(e).__name__}")
                logger.error(f"Error message: {str(e)}")
                logger.error(f"Full traceback:\n{traceback.format_exc()}")
                
                if attempt < self.retry_attempts - 1:
                    wait_time = self.retry_delay * (2 ** attempt)
                    logger.warning(f"Retrying in {wait_time} seconds...")
                    await asyncio.sleep(wait_time)
                    continue
        
        # All attempts failed
        logger.error(f"❌ All MT5 fetch attempts failed for {mt5_login}: {last_error}")
        logger.error(f"Bridge URL: {self.bridge_url}")
        logger.error(f"API Key configured: {'Yes' if self.api_key else 'No'}")
        raise Exception(f"Failed to fetch MT5 data after {self.retry_attempts} attempts: {last_error}")
    
    async def _fetch_via_bridge(self, mt5_login: str) -> Dict[str, Any]:
        """Fetch data via MT5 Bridge API"""
        try:
            url = f"{self.bridge_url}/api/mt5/account/{mt5_login}/info"
            logger.info(f"🔗 Connecting to MT5 Bridge: {url}")
            logger.info(f"🔑 API Key configured: {'Yes' if self.api_key else 'No'}")
            logger.info(f"⏱️  Timeout: {self.timeout}s")
            
            if not self.session:
                logger.error("❌ HTTP session not initialized!")
                return {'success': False, 'error': 'HTTP session not initialized'}
            
            async with self.session.get(url) as response:
                logger.info(f"📡 Bridge response status: {response.status}")
                
                if response.status == 200:
                    try:
                        data = await response.json()
                        logger.info(f"✅ Bridge returned data keys: {list(data.keys())}")
                        
                        # CRITICAL FIX: Extract from live_data nested object
                        live_data = data.get('live_data', {})
                        if not live_data:
                            # Fallback: Try root level (old format compatibility)
                            live_data = data
                        
                        balance = float(live_data.get('balance', 0))
                        logger.info(f"🔍 Extracted balance for {mt5_login}: ${balance:,.2f} from live_data")
                        
                        return {
                            'success': True,
                            'balance': balance,
                            'equity': float(live_data.get('equity', 0)),
                            'profit': float(live_data.get('profit', 0)),
                            'margin': float(live_data.get('margin', 0)),
                            'data_source': 'mt5_bridge'
                        }
                    except Exception as json_error:
                        error_text = await response.text()
                        logger.error(f"❌ Bridge JSON parse error: {str(json_error)}")
                        logger.error(f"Raw response: {error_text[:500]}")
                        return {'success': False, 'error': f"JSON parse error: {str(json_error)}"}
                else:
                    error_text = await response.text()
                    logger.error(f"❌ Bridge HTTP error {response.status}: {error_text[:500]}")
                    return {
                        'success': False,
                        'error': f"HTTP {response.status}: {error_text}"
                    }
                    
        except Exception as e:
            import traceback
            logger.error(f"❌ Bridge connection exception: {type(e).__name__}")
            logger.error(f"Exception message: {str(e)}")
            logger.error(f"Full traceback:\n{traceback.format_exc()}")
            return {
                'success': False,
                'error': f"Bridge connection error: {str(e)}"
            }
    
    async def _fetch_via_direct_api(self, mt5_login: str) -> Dict[str, Any]:
        """Fetch data via direct broker API (fallback method)"""
        try:
            # This would implement direct MEXAtlantic API calls
            # For now, return failure to indicate this method needs implementation
            return {
                'success': False,
                'error': 'Direct broker API not implemented yet'
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f"Direct API error: {str(e)}"
            }
    
    def validate_mt5_data(self, old_data: Dict, new_data: Dict, skip_zero_check: bool = False) -> Tuple[bool, str]:
        """Validate new MT5 data before updating database"""
        try:
            # Check if new data is reasonable
            old_balance = float(old_data.get('balance', 0))
            new_balance = float(new_data.get('balance', 0))
            
            # SMART ZERO BALANCE HANDLING:
            # Accept $0 if any of these conditions:
            # 1. skip_zero_check=True (verified condition)
            # 2. Account is SEPARATION type (can legitimately be $0)
            # 3. Old balance was already low (<$100) - natural drain
            # 4. This is capital reallocation period (end of month)
            
            fund_type = old_data.get('fund_type') or new_data.get('fund_type', '')
            is_separation = fund_type in ['SEPARATION', 'separation']
            old_balance_was_low = old_balance < 100
            
            if new_balance == 0 and old_balance > 0 and not skip_zero_check:
                # Allow $0 for separation accounts (normal)
                if is_separation:
                    logging.info(f"✅ Accepting $0 for SEPARATION account (was ${old_balance:.2f})")
                    return True, "Valid - SEPARATION account"
                
                # Allow $0 if old balance was already very low
                if old_balance_was_low:
                    logging.info(f"✅ Accepting $0 balance (was ${old_balance:.2f} - natural drain)")
                    return True, "Valid - natural balance drain"
                
                # For significant drops ($100+), this could be:
                # - Capital reallocation (legitimate)
                # - Account switching (technical issue)
                # Decision: ACCEPT IT but log for monitoring
                logging.warning(f"⚠️ Large balance drop: ${old_balance:.2f} → $0.00 (accepting as capital reallocation)")
                return True, "Accepted - potential capital reallocation"
            
            if old_balance > 0 and new_balance > 0:
                balance_change_pct = abs(new_balance - old_balance) / old_balance * 100
                
                # Alert if balance changed >50% in one sync (likely error)
                if balance_change_pct > 50:
                    return False, f"Suspicious balance change: {balance_change_pct:.1f}%"
            
            # Validate data types and ranges
            if not isinstance(new_balance, (int, float)) or new_balance < 0:
                return False, "Invalid balance value"
                
            new_equity = float(new_data.get('equity', 0))
            if not isinstance(new_equity, (int, float)) or new_equity < 0:
                return False, "Invalid equity value"
            
            return True, "Data validation passed"
            
        except Exception as e:
            return False, f"Validation error: {str(e)}"
    
    async def sync_single_account(self, mt5_login: str) -> MT5SyncResult:
        """Sync a single MT5 account with full error handling"""
        try:
            # Get current account data from database
            current_account = await self.db.mt5_accounts.find_one({
                "$or": [
                    {"account": int(mt5_login) if mt5_login.isdigit() else mt5_login},
                    {"account": mt5_login},
                    {"mt5_login": int(mt5_login) if mt5_login.isdigit() else mt5_login},
                    {"mt5_login": mt5_login}
                ]
            })
            
            if current_account is None:
                return MT5SyncResult(
                    mt5_login=mt5_login,
                    success=False,
                    old_balance=0,
                    new_balance=0,
                    balance_change=0,
                    sync_timestamp=datetime.now(timezone.utc),
                    error_message="Account not found in database"
                )
            
            old_balance = float(current_account.get('balance', 0))
            old_equity = float(current_account.get('equity', 0))
            
            # Fetch live MT5 data
            live_data = await self.fetch_mt5_data_with_retry(mt5_login)
            
            # Validate new data
            is_valid, validation_message = self.validate_mt5_data(current_account, live_data)
            if not is_valid:
                logger.warning(f"⚠️ Data validation failed for {mt5_login}: {validation_message}")
                return MT5SyncResult(
                    mt5_login=mt5_login,
                    success=False,
                    old_balance=old_balance,
                    new_balance=old_balance,  # Keep old balance
                    balance_change=0,
                    sync_timestamp=datetime.now(timezone.utc),
                    error_message=f"Validation failed: {validation_message}"
                )
            
            # Update database with new data
            new_balance = float(live_data['balance'])
            new_equity = float(live_data['equity'])
            new_profit = float(live_data['profit'])
            new_margin = float(live_data.get('margin', 0))
            
            update_data = {
                'balance': new_balance,
                'equity': new_equity,
                'profit': new_profit,
                'margin': new_margin,
                'updated_at': datetime.now(timezone.utc),
                'sync_status': 'success',
                'sync_error': None,
                'last_sync_timestamp': datetime.now(timezone.utc).isoformat()
            }
            
            result = await self.db.mt5_accounts.update_one(
                {"_id": current_account["_id"]},
                {"$set": update_data}
            )
            
            if result.modified_count > 0:
                balance_change = new_balance - old_balance
                
                # Log significant changes
                if abs(balance_change) > 10:
                    logger.info(f"💰 Significant balance change for {mt5_login}: {old_balance:.2f} → {new_balance:.2f} (${balance_change:+.2f})")
                    await self._log_sync_event(mt5_login, old_balance, new_balance, "significant_change")
                
                # Log the successful sync
                await self._log_sync_event(mt5_login, old_balance, new_balance, "success")
                
                return MT5SyncResult(
                    mt5_login=mt5_login,
                    success=True,
                    old_balance=old_balance,
                    new_balance=new_balance,
                    balance_change=balance_change,
                    sync_timestamp=datetime.now(timezone.utc),
                    data_source=live_data.get('data_source', 'mt5_bridge')
                )
            else:
                return MT5SyncResult(
                    mt5_login=mt5_login,
                    success=False,
                    old_balance=old_balance,
                    new_balance=new_balance,
                    balance_change=0,
                    sync_timestamp=datetime.now(timezone.utc),
                    error_message="Database update failed"
                )
                
        except Exception as e:
            logger.error(f"❌ Error syncing account {mt5_login}: {str(e)}")
            await self._log_sync_event(mt5_login, 0, 0, "error", str(e))
            
            return MT5SyncResult(
                mt5_login=mt5_login,
                success=False,
                old_balance=0,
                new_balance=0,
                balance_change=0,
                sync_timestamp=datetime.now(timezone.utc),
                error_message=str(e)
            )
    
    async def _check_if_all_accounts_zero(self, live_data_list: List[Dict]) -> bool:
        """Check if ALL accounts are showing zero (true MT5 disconnection vs account switching)"""
        non_zero_count = sum(1 for data in live_data_list if float(data.get('balance', 0)) > 0)
        return non_zero_count == 0
    
    async def _check_bridge_health(self) -> Dict:
        """Check MT5 Bridge health status"""
        try:
            async with self.session.get(f"{self.bridge_url}/health", timeout=10) as response:
                if response.status == 200:
                    return await response.json()
                return {}
        except Exception as e:
            logger.error(f"Failed to check bridge health: {str(e)}")
            return {}
    
    async def _trigger_mt5_restart(self):
        """Trigger MT5 Terminal restart via GitHub Actions repository_dispatch"""
        try:
            logger.info("🔄 Triggering MT5 FULL SYSTEM restart via GitHub Actions...")
            
            import httpx
            github_token = os.getenv('GITHUB_TOKEN')
            github_repo = os.getenv('GITHUB_REPOSITORY', 'chavapalmarubin-lab/FIDUS')
            
            if not github_token:
                logger.error("❌ GITHUB_TOKEN not found - cannot trigger auto-restart")
                logger.critical("🚨 MANUAL INTERVENTION REQUIRED: Restart MT5 Terminal on VPS manually")
                return
            
            # Use repository_dispatch for full restart
            url = f"https://api.github.com/repos/{github_repo}/dispatches"
            headers = {
                "Authorization": f"Bearer {github_token}",
                "Accept": "application/vnd.github.v3+json",
                "Content-Type": "application/json"
            }
            data = {
                "event_type": "mt5-full-restart",
                "client_payload": {
                    "trigger": "auto_sync_service",
                    "reason": "MT5 Terminal disconnected from broker - all accounts showing $0",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(url, headers=headers, json=data, timeout=30)
                
                if response.status_code == 204:
                    logger.info("✅ MT5 FULL RESTART workflow triggered successfully via repository_dispatch")
                else:
                    logger.error(f"❌ Failed to trigger MT5 restart: HTTP {response.status_code} - {response.text}")
                    logger.critical("🚨 MANUAL INTERVENTION REQUIRED: Check GitHub Actions or restart MT5 manually")
        except Exception as e:
            logger.error(f"❌ Failed to trigger MT5 restart: {str(e)}")
            logger.critical("🚨 MANUAL INTERVENTION REQUIRED: Restart MT5 Terminal on VPS manually")
    
    async def sync_all_accounts(self) -> Dict[str, Any]:
        """Sync all active MT5 accounts"""
        try:
            logger.info("🔄 Starting MT5 sync for all accounts...")
            
            # CRITICAL FIX: Read from mt5_account_config (source of truth) not mt5_accounts
            accounts_cursor = self.db.mt5_account_config.find({"is_active": True})
            accounts = await accounts_cursor.to_list(length=100)
            
            if accounts is None or len(accounts) == 0:
                logger.warning("⚠️ No active MT5 accounts found for sync")
                return {
                    'total_accounts': 0,
                    'successful_syncs': 0,
                    'failed_syncs': 0,
                    'sync_results': [],
                    'overall_status': 'no_accounts'
                }
            
            # Sync each account
            sync_results = []
            successful_syncs = 0
            failed_syncs = 0
            
            # CRITICAL: First check MT5 Bridge health to detect Terminal disconnection
            # BUT: Be smart about capital reallocation periods (end of month)
            try:
                bridge_health = await self._check_bridge_health()
                terminal_connected = bridge_health.get('mt5', {}).get('terminal_info', {}).get('connected')
                
                # Only trigger restart if BOTH conditions are true:
                # 1. Terminal reports as disconnected
                # 2. >80% of accounts show $0 balance
                # 3. Accounts are NOT syncing successfully (rules out reallocation)
                if not terminal_connected:
                    # Check ALL active non-separation accounts
                    accounts_list = await self.db.mt5_accounts.find({
                        'fund_code': {'$nin': ['SEPARATION']}
                    }).to_list(length=100)
                    
                    # Filter out None fund_code and get active accounts
                    active_accounts = [acc for acc in accounts_list if acc.get('fund_code') not in [None, 'SEPARATION']]
                    zero_balance_count = sum(1 for acc in active_accounts if acc.get('balance', 0) == 0)
                    total_active = len(active_accounts)
                    zero_balance_pct = (zero_balance_count / total_active) if total_active > 0 else 0
                    
                    if total_active == 0:
                        logger.info("ℹ️ No active trading accounts found for terminal check")
                    else:
                        logger.debug(f"Terminal check: {zero_balance_count}/{total_active} accounts at $0 ({zero_balance_pct*100:.0f}%)")
                    
                    # Check if accounts are syncing (updated recently)
                    from datetime import timedelta
                    recent_cutoff = datetime.now(timezone.utc) - timedelta(minutes=10)
                    recently_synced = sum(1 for acc in active_accounts 
                                        if acc.get('updated_at') and 
                                        (isinstance(acc['updated_at'], datetime) and acc['updated_at'] >= recent_cutoff))
                    
                    # Only restart if >80% show $0 AND accounts are NOT syncing (real disconnect)
                    if total_active > 0 and zero_balance_pct > 0.8 and recently_synced == 0:
                        logger.critical("🚨 MT5 Terminal NOT CONNECTED to broker - initiating auto-restart")
                        logger.critical(f"   {zero_balance_count}/{total_active} accounts showing $0 balance")
                        logger.critical(f"   {recently_synced}/{total_active} accounts recently synced")
                        await self._send_alert(f"MT5 Terminal disconnected. {zero_balance_count}/{total_active} accounts showing $0 and NOT syncing. Auto-restart initiated.")
                        await self._trigger_mt5_restart()
                        # Wait for restart and return early
                        return {
                            'total_accounts': len(accounts),
                            'successful_syncs': 0,
                            'failed_syncs': len(accounts),
                            'sync_results': [],
                            'overall_status': 'mt5_disconnected_restart_triggered',
                            'sync_timestamp': datetime.now(timezone.utc).isoformat()
                        }
                    elif total_active > 0 and zero_balance_pct > 0.8 and recently_synced > 0:
                        logger.info(f"ℹ️ {zero_balance_count}/{total_active} accounts at $0 but {recently_synced} syncing recently - likely capital reallocation")
                    elif total_active > 0:
                        logger.debug(f"ℹ️ Terminal disconnected warning but only {zero_balance_pct*100:.0f}% at $0 - not critical")
            except Exception as e:
                logger.error(f"Failed to check MT5 Bridge health: {str(e)}")
            
            for account in accounts:
                mt5_login = str(account.get('account') or account.get('mt5_login') or account.get('login', ''))
                if mt5_login and mt5_login != 'None':
                    result = await self.sync_single_account(mt5_login)
                    sync_results.append(result)
                    
                    if result.success:
                        successful_syncs += 1
                        self.sync_stats['accounts_synced'].add(mt5_login)
                    else:
                        failed_syncs += 1
                        logger.warning(f"⚠️ Failed to sync account {mt5_login}: {result.error_message}")
            
            # Update sync statistics
            self.sync_stats['total_syncs'] += 1
            self.sync_stats['successful_syncs'] += successful_syncs
            self.sync_stats['failed_syncs'] += failed_syncs
            self.sync_stats['last_sync_time'] = datetime.now(timezone.utc)
            
            # Store results for monitoring
            self.last_sync_results = {
                'sync_time': datetime.now(timezone.utc),
                'results': sync_results,
                'summary': {
                    'total': len(sync_results),
                    'successful': successful_syncs,
                    'failed': failed_syncs,
                    'success_rate': (successful_syncs / len(sync_results) * 100) if sync_results else 0
                }
            }
            
            logger.info(f"✅ MT5 sync completed: {successful_syncs}/{len(sync_results)} accounts synced successfully")
            
            return {
                'total_accounts': len(sync_results),
                'successful_syncs': successful_syncs,
                'failed_syncs': failed_syncs,
                'success_rate': (successful_syncs / len(sync_results) * 100) if sync_results else 0,
                'sync_results': [
                    {
                        'mt5_login': r.mt5_login,
                        'success': r.success,
                        'balance_change': r.balance_change,
                        'new_balance': r.new_balance,
                        'error': r.error_message
                    } for r in sync_results
                ],
                'overall_status': 'success' if failed_syncs == 0 else 'partial_success',
                'sync_timestamp': datetime.now(timezone.utc).isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Error in sync_all_accounts: {str(e)}")
            return {
                'total_accounts': 0,
                'successful_syncs': 0,
                'failed_syncs': 0,
                'sync_results': [],
                'overall_status': 'error',
                'error': str(e)
            }
    
    async def start_background_sync(self):
        """Start automated background sync every 2 minutes"""
        if self.sync_running:
            logger.warning("⚠️ Background sync already running")
            return
        
        self.sync_running = True
        logger.info(f"🚀 Starting MT5 background sync (every {self.sync_interval} seconds)")
        
        while self.sync_running:
            try:
                start_time = time.time()
                
                # Perform sync
                result = await self.sync_all_accounts()
                
                sync_duration = time.time() - start_time
                logger.info(f"🔄 Background sync completed in {sync_duration:.1f}s: "
                           f"{result['successful_syncs']}/{result['total_accounts']} accounts")
                
                # Check for account 886528 specifically (our problem account)
                account_886528_result = None
                for sync_result in result.get('sync_results', []):
                    if sync_result['mt5_login'] == '886528':
                        account_886528_result = sync_result
                        break
                
                if account_886528_result:
                    if account_886528_result['success']:
                        logger.info(f"✅ Account 886528 synced: Balance = ${account_886528_result['new_balance']:.2f}, "
                                   f"Change = ${account_886528_result['balance_change']:+.2f}")
                    else:
                        logger.error(f"❌ Account 886528 sync failed: {account_886528_result.get('error', 'Unknown error')}")
                
                # Alert if sync success rate is low (below 50% is concerning)
                # BUT: Don't alert if syncs are succeeding but accounts just have $0 (capital reallocation)
                success_rate = result.get('success_rate', 0)
                total_accounts = result.get('total_accounts', 0)
                successful_syncs = result.get('successful_syncs', 0)
                
                if success_rate < 50 and total_accounts > 0:
                    # Check if this is a FALSE POSITIVE: syncs working but accounts have $0
                    # This happens during monthly capital reallocation
                    zero_balance_but_synced = 0
                    for sync_result in result.get('sync_results', []):
                        if sync_result.get('success') and sync_result.get('new_balance', 0) == 0:
                            zero_balance_but_synced += 1
                    
                    # If accounts are syncing successfully (just showing $0), this is NOT a problem
                    actual_failures = total_accounts - successful_syncs
                    if actual_failures > 0 and (actual_failures / total_accounts) > 0.5:
                        # Real failure: accounts not syncing at all
                        logger.warning(f"⚠️ Critically low sync success rate: {success_rate:.1f}% ({actual_failures} real failures)")
                        await self._send_alert(f"MT5 sync failures: {actual_failures}/{total_accounts} accounts failed to sync")
                    else:
                        # False positive: syncs working, accounts just have $0 (reallocation)
                        logger.info(f"ℹ️ Low success rate ({success_rate:.1f}%) but syncs are working - {zero_balance_but_synced} accounts with $0 (likely capital reallocation)")

                
            except Exception as e:
                logger.error(f"❌ Background sync error: {str(e)}")
                await self._send_alert(f"MT5 background sync error: {str(e)}")
            
            # Wait for next sync
            await asyncio.sleep(self.sync_interval)
    
    def stop_background_sync(self):
        """Stop background sync"""
        self.sync_running = False
        logger.info("🛑 MT5 background sync stopped")
    
    async def get_sync_dashboard(self) -> Dict[str, Any]:
        """Get comprehensive sync status dashboard"""
        try:
            # Get all MT5 accounts with their sync status
            accounts_cursor = self.db.mt5_accounts.find({})
            accounts = await accounts_cursor.to_list(length=100)
            
            dashboard = {
                'service_status': 'running' if self.sync_running else 'stopped',
                'total_accounts': len(accounts),
                'synced_accounts': 0,
                'failed_accounts': 0,
                'stale_accounts': 0,
                'never_synced': 0,
                'last_sync_time': self.sync_stats.get('last_sync_time'),
                'sync_stats': self.sync_stats.copy(),
                'accounts_detail': [],
                'critical_accounts': []  # Accounts with issues
            }
            
            current_time = datetime.now(timezone.utc)
            
            for account in accounts:
                mt5_login = str(account.get('account') or account.get('mt5_login') or account.get('login', ''))
                last_updated = account.get('updated_at') or account.get('last_sync_timestamp')
                
                # Calculate age of last sync
                if last_updated:
                    if isinstance(last_updated, str):
                        try:
                            last_updated = datetime.fromisoformat(last_updated.replace('Z', '+00:00'))
                        except:
                            last_updated = None
                    
                    if last_updated and last_updated.tzinfo is None:
                        last_updated = last_updated.replace(tzinfo=timezone.utc)
                
                age_minutes = None
                if last_updated:
                    age_minutes = (current_time - last_updated).total_seconds() / 60
                
                # Determine status
                if not last_updated:
                    status = 'never_synced'
                    dashboard['never_synced'] += 1
                elif age_minutes > 10:  # Stale if not updated in 10 minutes
                    status = 'stale'
                    dashboard['stale_accounts'] += 1
                elif account.get('sync_status') == 'failed':
                    status = 'failed'
                    dashboard['failed_accounts'] += 1
                else:
                    status = 'synced'
                    dashboard['synced_accounts'] += 1
                
                account_detail = {
                    'mt5_login': mt5_login,
                    'balance': float(account.get('balance', 0)),
                    'equity': float(account.get('equity', 0)),
                    'fund_code': account.get('fund_code'),
                    'broker_name': account.get('broker_name'),
                    'last_updated': last_updated.isoformat() if last_updated else None,
                    'age_minutes': round(age_minutes, 1) if age_minutes else None,
                    'status': status,
                    'sync_error': account.get('sync_error')
                }
                
                dashboard['accounts_detail'].append(account_detail)
                
                # Flag critical accounts (886528 and any with errors)
                if mt5_login == '886528' or status in ['failed', 'stale', 'never_synced']:
                    dashboard['critical_accounts'].append(account_detail)
            
            # Add recent sync results if available
            if hasattr(self, 'last_sync_results') and self.last_sync_results:
                dashboard['last_sync_results'] = self.last_sync_results
            
            return dashboard
            
        except Exception as e:
            logger.error(f"❌ Error generating sync dashboard: {str(e)}")
            return {
                'service_status': 'error',
                'error': str(e),
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
    
    async def _log_sync_event(self, mt5_login: str, old_balance: float, new_balance: float, 
                            event_type: str, error_message: str = None):
        """Log sync event to database for audit trail"""
        try:
            log_entry = {
                'mt5_login': mt5_login,
                'event_type': event_type,  # success, error, significant_change
                'old_balance': old_balance,
                'new_balance': new_balance,
                'balance_change': new_balance - old_balance,
                'timestamp': datetime.now(timezone.utc),
                'error_message': error_message
            }
            
            await self.db.mt5_sync_logs.insert_one(log_entry)
            
        except Exception as e:
            logger.error(f"Failed to log sync event: {str(e)}")
    
    async def _send_alert(self, message: str):
        """Send alert for critical MT5 issues via email (with throttling to prevent spam)"""
        
        # Check if alerts are enabled (can be disabled during capital reallocation)
        import os
        alerts_enabled = os.getenv('MT5_ALERTS_ENABLED', 'true').lower() == 'true'
        
        if not alerts_enabled:
            logger.info(f"ℹ️ Alert suppressed (MT5_ALERTS_ENABLED=false): {message}")
            return
        
        # Check if we've sent this alert recently (throttling)
        from datetime import datetime, timezone
        
        alert_key = message[:50]  # Use first 50 chars as unique key
        current_time = datetime.now(timezone.utc).timestamp()
        last_alert_time = self.last_alert_times.get(alert_key, 0)
        
        # If we sent the same alert within cooldown period, skip it
        if current_time - last_alert_time < self.alert_cooldown:
            time_since_last = int(current_time - last_alert_time)
            logger.info(f"⏭️ Skipping duplicate alert (sent {time_since_last}s ago): {alert_key}...")
            return
        
        # Record this alert time
        self.last_alert_times[alert_key] = current_time
        
        logger.critical(f"🚨 ALERT: {message}")
        
        try:
            # Send alert using AlertService
            from alert_service import AlertService
            alert_service = AlertService(self.db)
            
            await alert_service.trigger_alert(
                component="mt5_bridge",
                component_name="MT5 Bridge",
                severity="critical",
                status="DEGRADED",
                message=message,
                details={"sync_rate": self.sync_stats.get('success_rate', 0)}
            )
            logger.info("✅ Alert email sent successfully")
        except Exception as e:
            logger.error(f"❌ Failed to send alert email: {str(e)}")
            # Fallback: At least log it prominently
            logger.critical(f"🚨🚨🚨 UNDELIVERED ALERT: {message}")

    
    async def close(self):
        """Clean shutdown"""
        self.stop_background_sync()
        if self.session and not self.session.closed:
            await self.session.close()
        logger.info("✅ MT5 Auto-Sync Service closed")

# Global instance
mt5_sync_service = MT5AutoSyncService()

# Startup function for FastAPI
async def start_mt5_sync_service():
    """Start the MT5 sync service"""
    success = await mt5_sync_service.initialize()
    if success:
        # Start background sync task
        asyncio.create_task(mt5_sync_service.start_background_sync())
        logger.info("🚀 MT5 Auto-Sync Service started successfully")
    else:
        logger.error("❌ Failed to start MT5 Auto-Sync Service")
    return success

# Shutdown function for FastAPI
async def stop_mt5_sync_service():
    """Stop the MT5 sync service"""
    await mt5_sync_service.close()
    logger.info("🛑 MT5 Auto-Sync Service stopped")
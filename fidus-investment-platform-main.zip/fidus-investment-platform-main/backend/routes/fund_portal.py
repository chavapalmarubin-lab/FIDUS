"""
FIDUS Fund Portal — Complete API with risk metrics, equity curve, daily P&L.
Uses same db pattern as franchise routes (proven on Render).
"""
from fastapi import APIRouter, HTTPException, Header
from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime, timezone, timedelta
import os, logging, jwt, math

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/fund", tags=["FIDUS Fund Portal"])

FUND_ACCOUNT = 2210
JWT_SECRET = os.environ.get("JWT_SECRET_KEY", "fidus-production-secret-2025-secure-key")


async def get_database():
    client = AsyncIOMotorClient(os.environ.get('MONGO_URL'))
    return client[os.environ.get('DB_NAME', 'fidus_production')]


def _auth(authorization: str):
    if not authorization:
        raise HTTPException(status_code=401, detail="Auth required")
    try:
        jwt.decode(authorization.replace("Bearer ", ""), JWT_SECRET, algorithms=["HS256"])
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


@router.get("/overview")
async def fund_overview(authorization: str = Header(None)):
    _auth(authorization)
    db = await get_database()
    acc = await db.mt5_accounts.find_one({"account": FUND_ACCOUNT}, {"_id": 0})
    if not acc:
        raise HTTPException(status_code=404, detail="Fund not found")

    equity = float(acc.get("equity", 0))
    initial = float(acc.get("initial_allocation", 0))
    wd = float(acc.get("total_withdrawals", 0))
    pnl = equity + wd - initial
    ret = (pnl / initial * 100) if initial > 0 else 0
    ad = acc.get("allocation_start_date")
    if ad and hasattr(ad, 'tzinfo') and ad.tzinfo is None:
        ad = ad.replace(tzinfo=timezone.utc)
    since = ad or datetime(2026, 3, 23, tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - since).days if since else 0

    # Daily P&L for equity curve + risk metrics
    daily_pipeline = [
        {"$match": {"account": FUND_ACCOUNT, "type": {"$ne": 2}, "time": {"$gte": since}}},
        {"$addFields": {"day": {"$dateToString": {"format": "%Y-%m-%d", "date": "$time"}}}},
        {"$group": {"_id": "$day", "pnl": {"$sum": "$profit"}, "trades": {"$sum": 1}}},
        {"$sort": {"_id": 1}}
    ]
    daily = list(await db.mt5_deals_history.aggregate(daily_pipeline).to_list(200))

    # Equity curve
    running = initial
    peak = initial
    max_dd = 0
    equity_curve = []
    daily_returns = []
    for d in daily:
        p = float(d["pnl"])
        running += p
        peak = max(peak, running)
        dd = ((running - peak) / peak * 100) if peak > 0 else 0
        max_dd = min(max_dd, dd)
        rate = (p / (running - p) * 100) if (running - p) > 0 else 0
        daily_returns.append(rate)
        equity_curve.append({"date": d["_id"], "equity": round(running, 2), "pnl": round(p, 2), "dd": round(dd, 2), "trades": d["trades"]})

    # Period returns
    now = datetime.now(timezone.utc)
    periods = {}
    for label, days_back in [("day", 1), ("week", 7), ("month", 30), ("quarter", 90), ("year", 365), ("all", 9999)]:
        cutoff = (now - timedelta(days=days_back)).strftime("%Y-%m-%d")
        period_pnl = sum(float(d["pnl"]) for d in daily if d["_id"] >= cutoff)
        periods[label] = round(period_pnl / initial * 100, 2) if initial > 0 else 0

    # Risk metrics
    if len(daily_returns) > 1:
        mean_r = sum(daily_returns) / len(daily_returns)
        std_r = (sum((r - mean_r)**2 for r in daily_returns) / len(daily_returns)) ** 0.5
        down = [r for r in daily_returns if r < 0]
        down_std = (sum((r - mean_r)**2 for r in down) / len(down)) ** 0.5 if down else std_r
        sharpe = round((mean_r / std_r * math.sqrt(252)) if std_r > 0 else 0, 2)
        sortino = round((mean_r / down_std * math.sqrt(252)) if down_std > 0 else 0, 2)
        best = round(max(daily_returns), 2)
        worst = round(min(daily_returns), 2)
        pos = sum(1 for r in daily_returns if r > 0)
        neg = sum(1 for r in daily_returns if r < 0)
    else:
        sharpe = sortino = best = worst = 0; pos = neg = 0

    return {"success": True,
        "fund": {"account": FUND_ACCOUNT, "name": acc.get("manager_name"), "equity": round(equity, 2), "initial": round(initial, 2), "true_pnl": round(pnl, 2), "return_pct": round(ret, 2), "withdrawals": round(wd, 2), "start_date": str(since)[:10], "age_days": age},
        "periods": periods,
        "risk_metrics": {"sharpe": sharpe, "sortino": sortino, "max_drawdown": round(abs(max_dd), 2), "best_day": best, "worst_day": worst, "positive_days": pos, "negative_days": neg, "recovery_factor": round(abs(ret / max_dd) if max_dd != 0 else 0, 2), "calmar": round(abs(ret / max_dd) if max_dd != 0 else 0, 2)},
        "equity_curve": equity_curve,
    }


@router.get("/trading")
async def fund_trading(authorization: str = Header(None)):
    _auth(authorization)
    db = await get_database()
    pipeline = [
        {"$match": {"account": FUND_ACCOUNT, "type": {"$ne": 2}, "profit": {"$ne": 0}}},
        {"$group": {"_id": None, "total_trades": {"$sum": 1},
            "wins": {"$sum": {"$cond": [{"$gt": ["$profit", 0]}, 1, 0]}},
            "losses": {"$sum": {"$cond": [{"$lt": ["$profit", 0]}, 1, 0]}},
            "gross_profit": {"$sum": {"$cond": [{"$gt": ["$profit", 0]}, "$profit", 0]}},
            "gross_loss": {"$sum": {"$cond": [{"$lt": ["$profit", 0]}, "$profit", 0]}},
            "total_pnl": {"$sum": "$profit"},
            "max_win": {"$max": "$profit"}, "max_loss": {"$min": "$profit"},
            "avg_win": {"$avg": {"$cond": [{"$gt": ["$profit", 0]}, "$profit", None]}},
            "avg_loss": {"$avg": {"$cond": [{"$lt": ["$profit", 0]}, "$profit", None]}},
        }}
    ]
    r = list(await db.mt5_deals_history.aggregate(pipeline).to_list(1))
    s = r[0] if r else {}
    t = s.get("total_trades", 0)
    return {"success": True, "trading": {
        "total_trades": t, "wins": s.get("wins", 0), "losses": s.get("losses", 0),
        "win_rate": round(s.get("wins", 0) / t * 100, 1) if t > 0 else 0,
        "profit_factor": round(abs(float(s.get("gross_profit", 0)) / float(s.get("gross_loss", 1))), 2) if s.get("gross_loss") else 0,
        "gross_profit": round(float(s.get("gross_profit", 0)), 2),
        "gross_loss": round(float(s.get("gross_loss", 0)), 2),
        "total_pnl": round(float(s.get("total_pnl", 0)), 2),
        "max_win": round(float(s.get("max_win", 0) or 0), 2),
        "max_loss": round(float(s.get("max_loss", 0) or 0), 2),
        "avg_win": round(float(s.get("avg_win", 0) or 0), 2),
        "avg_loss": round(float(s.get("avg_loss", 0) or 0), 2),
        "expectancy": round(float(s.get("total_pnl", 0)) / t, 2) if t > 0 else 0,
    }}


@router.get("/instruments")
async def fund_instruments(authorization: str = Header(None)):
    _auth(authorization)
    db = await get_database()
    pipeline = [
        {"$match": {"account": FUND_ACCOUNT, "type": {"$ne": 2}, "profit": {"$ne": 0}}},
        {"$group": {"_id": "$symbol", "count": {"$sum": 1}, "volume": {"$sum": "$volume"},
                    "pnl": {"$sum": "$profit"}, "wins": {"$sum": {"$cond": [{"$gt": ["$profit", 0]}, 1, 0]}}}},
        {"$sort": {"count": -1}}
    ]
    insts = list(await db.mt5_deals_history.aggregate(pipeline).to_list(20))
    total = sum(i["count"] for i in insts) or 1
    return {"success": True, "instruments": [
        {"symbol": i["_id"], "count": i["count"], "pnl": round(float(i["pnl"]), 2),
         "volume": round(float(i["volume"]), 2), "count_pct": round(i["count"] / total * 100, 1),
         "win_rate": round(i["wins"] / i["count"] * 100, 1) if i["count"] > 0 else 0}
        for i in insts
    ]}


@router.get("/trades")
async def fund_trades(limit: int = 200, authorization: str = Header(None)):
    _auth(authorization)
    db = await get_database()
    trades = await db.mt5_deals_history.find(
        {"account": FUND_ACCOUNT, "type": {"$ne": 2}, "profit": {"$ne": 0}},
        {"_id": 0, "symbol": 1, "profit": 1, "volume": 1, "time": 1, "price": 1}
    ).sort("time", -1).to_list(limit)
    for t in trades:
        if t.get("time"): t["time"] = t["time"].isoformat()
    return {"success": True, "trades": trades}
